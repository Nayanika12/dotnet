﻿using Newtonsoft.Json;
using NUnit.Framework;
using RestSharp;
using System;
using System.Linq;
using System.Net;
using System.Collections.Generic;

namespace DemobackendDB
{
    class RestService
    {
        string endpointUrl = "https://reqres.in/api/users";
        public RestClient endpoint = null;
        //public RestClient SetEndpoint(string endpointUrl)
        //{
        //    endpoint = new RestClient(endpointUrl);
        //    return endpoint;
        //}


        public bool requestisaccepted()
        {

            endpoint = new RestClient(endpointUrl);
            var request = new RestRequest(Method.POST);
            var response = endpoint.Execute(request);

            bool isAccepted = (response.StatusCode == System.Net.HttpStatusCode.Accepted || response.StatusCode == System.Net.HttpStatusCode.Created);
            return isAccepted;


        }
    }
}

