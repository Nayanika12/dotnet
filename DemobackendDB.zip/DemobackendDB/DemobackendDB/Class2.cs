﻿//using System;
//using System.IO;
//using System.Linq;
//using System.Runtime.Serialization;
//using System.Runtime.Serialization.Formatters.Binary;
//using System.Text;
//using System.Threading.Tasks;
//namespace DemoApplication
//{
//    [Serializable]
//    class Class2
//    {
//        public String Job;
//        public String Name;
//        static void Main(string[] args)
//        {
//            Class2 obj = new Class2();
//            obj.Job = "Leader";
//            obj.Name = "morpheus";

//            IFormatter formatter = new BinaryFormatter();
//            Stream stream = new FileStream(@"‪D:\nayanika\nayanika.txt", FileMode.Create, FileAccess.Write);

//            formatter.Serialize(stream, obj);
//            stream.Close();

//            stream = new FileStream(@"‪D:\nayanika\nayanika.txt", FileMode.Open, FileAccess.Read);
//            Class2 objnew = (Class2)formatter.Deserialize(stream);

//            Console.WriteLine(objnew.Job);
//            Console.WriteLine(objnew.Name);

//            Console.ReadKey();
//        }
//    }
//}
