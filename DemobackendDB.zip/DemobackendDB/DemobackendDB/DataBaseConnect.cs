﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemobackendDB
{
    class DataBaseConnect {

        public string[] getValue()
        {
            string[] value = new string[2];
            string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Nayanika\data.mdb";
            string strSQL = "SELECT name,job FROM employee ";
            // Create a connection  
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                // Create a command and set its connection  
                OleDbCommand command = new OleDbCommand(strSQL, connection);
                // Open the connection and execute the select command.  
                try
                {
                    // Open connecton  
                    connection.Open();
                    // Execute command  
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                           value[0]=  reader["name"].ToString();
                           value[1]= reader["job"].ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                // The connection is automatically closed becasuse of using block.  
            }
            return value;
            
        }

    }
}
