﻿using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace DemobackendDB
{
    [Binding]
    public class SpecFlowFeature1Steps
    {
        private bool hasBeenAccepted = false;


        [Given]
        public void Given_I_have_the_payload_with_the_below_value_and_I_send_the_request_using_the_payload(Table table)
        {
            RestService r1 = new RestService();
            this.hasBeenAccepted= r1.requestisaccepted();
        }
        
        [When]
        public void When_The_request_is_accepted_from_the_system()
        {
            Assert.IsTrue(hasBeenAccepted, "Message has not been accepted from the system");
        }

        [When]
        public void When_the_database_assertions_are_passing()
        {
            ScenarioContext.Current.Pending();
        }

    }
}

